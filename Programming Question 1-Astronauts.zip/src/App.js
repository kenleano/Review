import logo from './logo.svg';
import './App.css';
import AstronautCard from './components/AstronautCard';
import AstronautCard2 from './components/AstronautCard2';
function App() {
  return (
    <div className="App">
      <AstronautCard />
    </div>
  );
}

export default App;
